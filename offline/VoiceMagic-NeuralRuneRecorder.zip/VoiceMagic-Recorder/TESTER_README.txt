VoiceMagic — offline recorder / автономная запись
English · Русский · Українська · Norsk (bokmål)

ENGLISH
Extract the ZIP and open recorder.html in desktop Chrome or Edge. No installation,
Python, hosting or internet is needed. Start-Recorder.cmd (Windows) and
Start-Recorder.command (macOS) also open the file.
1. Choose your language and anonymous participant ID. Reuse the same ID on every
   device and session. Do not enter your real name.
2. Read the project introduction. Enter your native language and microphone/room
   details, then give consent if you agree. Opening the page never records audio.
3. Record the 14 individual commands (12 runes + 2 cancels), then seven randomly
   selected spells. Pronunciation hints appear with each task. Say the rune names,
   not translations. The release word is always Atu (/a.tu/, ah-too).
4. Listen to each take from start to finish, enter what you actually said, and
   confirm the label. Correct mistakes honestly; exclude unclear/interrupted takes
   and record again. Next becomes available after a verified take.
5. On the thank-you screen, download the ZIP. You can email the result to
   konopelkoyan@gmail.com: attach the downloaded ZIP yourself. No automatic upload.
Recordings, drafts, random selection and progress are stored locally when browser
storage works. Download backups using the button on the recording screen too.
Use the same browser/file location to resume; clearing browser data can lose access.
Consent is requested again after reopening. Do not record others without consent.

РУССКИЙ
Распакуйте ZIP и откройте recorder.html в Chrome или Edge на компьютере. Установка,
Python, хостинг и интернет не нужны. Можно использовать Start-Recorder.cmd (Windows)
или Start-Recorder.command (macOS).
1. Выберите язык и анонимный ID. Используйте один ID во всех сессиях и на всех
   устройствах. Не указывайте ФИО.
2. Прочитайте описание проекта, укажите родной язык, микрофон и условия. Отметьте
   согласие, если согласны. Открытие страницы само по себе не включает микрофон.
3. Запишите по очереди 14 команд (12 рун и 2 отмены), затем семь случайных заклинаний.
   Рядом есть подсказки произношения. Названия не переводятся; выпуск — Ату (а-ту).
4. Каждую попытку прослушайте целиком, укажите реально произнесённые слова и
   подтвердите разметку. Исправляйте оговорки; неясную или прерванную попытку исключите
   и запишите заново. Кнопка «Дальше» доступна после подтверждённой записи.
5. На экране благодарности скачайте ZIP. Результат можно отправить на
   konopelkoyan@gmail.com, самостоятельно прикрепив ZIP к письму. Автоотправки нет.
Записи, черновики, выбор заклинаний и прогресс сохраняются локально, если хранилище
браузера доступно. На экране записи также можно скачать резервный ZIP. Для продолжения
используйте тот же браузер и расположение файла; очистка данных может лишить доступа.
После открытия согласие нужно отметить заново. Не записывайте других людей без согласия.

УКРАЇНСЬКА
Розпакуйте ZIP і відкрийте recorder.html у Chrome або Edge на комп’ютері. Установлення,
Python, хостинг та інтернет не потрібні. Також можна відкрити Start-Recorder.cmd
(Windows) або Start-Recorder.command (macOS).
1. Виберіть мову й анонімний ID. Використовуйте той самий ID у всіх сесіях та на всіх
   пристроях. Не вказуйте справжнє ім’я.
2. Прочитайте опис проєкту, укажіть рідну мову, мікрофон та умови. Позначте згоду,
   якщо погоджуєтеся. Відкриття сторінки саме по собі не вмикає мікрофон.
3. Запишіть по черзі 14 команд (12 рун і 2 скасування), потім сім випадкових заклинань.
   Поруч є підказки вимови. Назви не перекладаються; завершальна руна — Ату (а-ту).
4. Прослухайте кожну спробу повністю, укажіть справді вимовлені слова та підтвердьте
   розмітку. Виправляйте обмовки; неясну чи перервану спробу виключіть і запишіть знову.
   Кнопка «Далі» доступна після підтвердженого запису.
5. На екрані подяки завантажте ZIP. Результат можна надіслати на
   konopelkoyan@gmail.com, самостійно прикріпивши ZIP до листа. Автонадсилання немає.
Записи, чернетки, вибір заклинань і прогрес зберігаються локально, якщо сховище
браузера доступне. На екрані запису також можна завантажити резервний ZIP. Продовжуйте
в тому самому браузері й з того самого розташування файлу; очищення даних може
позбавити доступу. Після відкриття згоду слід позначити знову. Не записуйте інших без згоди.

NORSK (BOKMÅL)
Pakk ut ZIP-filen og åpne recorder.html i Chrome eller Edge på datamaskinen. Du trenger
ikke installasjon, Python, hosting eller internett. Start-Recorder.cmd (Windows) og
Start-Recorder.command (macOS) åpner også filen.
1. Velg språk og anonym deltaker-ID. Bruk samme ID i alle økter og på alle enheter.
   Ikke oppgi ditt virkelige navn.
2. Les om prosjektet, fyll inn morsmål, mikrofon og opptaksforhold, og gi samtykke
   hvis du er enig. Mikrofonen starter ikke bare fordi du åpner siden.
3. Ta opp 14 enkeltkommandoer (12 runer og 2 avbrytkommandoer), deretter sju tilfeldig
   valgte trylleformler. Uttalehjelp vises for hver oppgave. Ikke oversett runenavnene.
   Avslutningsrunen er Atu (/a.tu/), a-to i norsk uttalehjelp: o som i «bok».
4. Lytt til hvert opptak fra start til slutt, skriv det du faktisk sa, og bekreft.
   Rett feil ærlig; utelat uklare/avbrutte opptak og ta opp på nytt. «Neste» blir
   tilgjengelig etter et kontrollert opptak.
5. Last ned ZIP-filen på takkesiden. Du kan sende resultatet til
   konopelkoyan@gmail.com ved å legge ved ZIP-filen selv. Ingenting sendes automatisk.
Opptak, utkast, tilfeldig utvalg og fremdrift lagres lokalt når nettleserlagring virker.
Last også ned sikkerhetskopier fra opptakssiden. Bruk samme nettleser og filplassering
for å fortsette; sletting av nettleserdata kan fjerne tilgangen. Gi samtykke på nytt
når du åpner siden igjen. Ikke ta opp andre personer uten samtykke.

Optional local-server fallback / Дополнительный локальный запуск:
If your browser blocks file-based microphone access, allow microphone access in
browser/system settings or try desktop Chrome/Edge. With Python 3 installed:
Windows: Start-Local-Server.cmd
macOS/Linux: python3 serve.py --open
Keep the terminal open. This binds only to this computer; hosting is not required.
