@echo off
rem No Python, no server and no browser security overrides.
start "" "%~dp0recorder.html"
