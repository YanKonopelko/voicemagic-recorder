#!/bin/sh
# Optional macOS convenience launcher. Double-clicking recorder.html also works.
cd -- "$(dirname -- "$0")" || exit 1
open ./recorder.html
