"""Local recorder: python Tools/NeuralRunes/serve.py; open http://localhost:8765.

Loopback only. No upload endpoint; the recorder exports a local ZIP.
"""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import argparse
import webbrowser

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__); p.add_argument('--port', type=int, default=8765)
    p.add_argument('--open', action='store_true', help='Open the recorder in the default browser')
    a = p.parse_args()
    handler = partial(SimpleHTTPRequestHandler, directory=str(Path(__file__).parent))
    try:
        server = ThreadingHTTPServer(('127.0.0.1', a.port), handler)
    except OSError:
        # Another recorder may already use the default port. Let the OS choose.
        server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
    url = f'http://127.0.0.1:{server.server_port}/recorder.html'
    print(f'Open {url} - Ctrl+C to stop', flush=True)
    if a.open:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
