@echo off
cd /d "%~dp0"
rem Optional fallback for browsers that restrict local-file microphone access.
where py >nul 2>nul
if not errorlevel 1 (
  py -3 serve.py --open
  goto done
)
where python >nul 2>nul
if not errorlevel 1 (
  python serve.py --open
  goto done
)
echo Python 3 not found. Normally, just open recorder.html in Chrome or Edge.
echo This optional fallback needs Python 3 from https://www.python.org/.
:done
pause
